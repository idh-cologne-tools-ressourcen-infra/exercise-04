package csvManipulator;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.opencsv.exceptions.CsvException;

public class Application {
	
	//THIS CODE USES ABSOLUTE FILE-PATHS!
	/*/
	 * Sources: 
	 * https://stackoverflow.com/questions/13969254/unwanted-double-quotes-in-generated-csv-file
	 * https://www.baeldung.com/opencsv
	 */
	

	public static void main(String[] args) {
		File csvFile = new File("C:/Users/Tim E/Desktop/Linguistische_Datenverarbeitung_AM1/git-exercise-4/exercise-04/data/train.csv");
		Reader reader = null;
		try {
			reader = Files.newBufferedReader(Paths.get(csvFile.getPath()));
		} catch (IOException e) {
			e.printStackTrace();
		}
		CSVReader csvReader = new CSVReader(reader);
		List<String[]> records = null;
		try {
			records = csvReader.readAll();
			for (int i = 1; i < records.size(); i++) {
				records.get(i)[3] = records.get(i)[3].replaceAll("\"(.*?)\"", "").trim();
				records.get(i)[3] = "\"" + records.get(i)[3] + "\"";
//				System.out.println(records.get(i)[3]);
			}
			
		} catch (IOException | CsvException e) {
			e.printStackTrace();
		}
		
		File csvFileV2 = new File("C:/Users/Tim E/Desktop/Linguistische_Datenverarbeitung_AM1/git-exercise-4/exercise-04/data/train_WO_NICKNAMES.csv");
		try {
			CSVWriter writer = new CSVWriter(new FileWriter(csvFileV2), CSVWriter.DEFAULT_SEPARATOR, CSVWriter.NO_QUOTE_CHARACTER, CSVWriter.NO_QUOTE_CHARACTER, CSVWriter.DEFAULT_LINE_END);
			for (String[] updatedRecord : records) {
				writer.writeNext(updatedRecord);
			}
			writer.close();
			csvReader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}

}
